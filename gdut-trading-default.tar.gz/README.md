开发框架2.0使用说明：https://docs.bk.tencent.com/blueapps/USAGE.html
